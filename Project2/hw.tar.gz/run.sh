#!/bin/sh
python project2.py
